# 📱 Kit de Divulgação — Diário da Riqueza

**20 postagens prontas para publicar** — cada legenda já vem formatada com **título**, **texto** e **4 hashtags**. É só copiar, colar e publicar.

## 📌 Como usar

- **Ordem sugerida**: 1 postagem por dia, seguindo a numeração (01 → 20). Assim você tem 20 dias de conteúdo.
- **Formato**: todas as imagens são quadradas **1080×1080** (funcionam no feed do Instagram, Facebook, LinkedIn, X/Twitter e WhatsApp Status).
- **Link**: como o Instagram não permite link clicável na legenda, coloque `diariodariqueza.vercel.app` na **bio** e escreva *"link na bio"* nos CTAs (posts 16–20). No Facebook, X e LinkedIn você pode incluir o link direto na legenda.
- **Marca**: a hashtag **#DiárioDaRiqueza** (com acento) é a assinatura do projeto — use sempre as 4 hashtags de cada post, sem cortar.

---

## 01 · 01-capa-marca.png

Sua vida financeira, finalmente organizada 📓✨

O Diário da Riqueza é um app gratuito que reúne tudo em um só lugar: registro de receitas e despesas, metas, orçamento, gráficos de evolução e um diário para anotar o que cada real significa para você. Simples de usar, direto do seu celular.

#DiárioDaRiqueza #FinançasPessoais #OrganizaçãoFinanceira #ControleFinanceiro

---

## 02 · 02-offline.png

Sem internet? Sem problema. 📵

O Diário da Riqueza funciona 100% offline. Você registra aquele gasto no ônibus, no mercado ou no meio da viagem — sem sinal não é mais desculpa. Tudo fica salvo no seu aparelho e sincroniza quando você quiser exportar.

#DiárioDaRiqueza #AppOffline #Praticidade #FinançasPessoais

---

## 03 · 03-privacidade.png

Seus dados financeiros são SÓ seus 🔒

Aqui não existe servidor guardando suas informações. Tudo que você registra fica salvo apenas no seu celular — nada é enviado, nada é vendido, nada é analisado. Privacidade de verdade, do jeito que deveria ser.

#DiárioDaRiqueza #Privacidade #SegurançaDigital #FinançasPessoais

---

## 04 · 04-sem-cadastro.png

Ninguém gosta de criar cadastro. Então a gente removeu. 😅

No Diário da Riqueza você abre o site e já começa a usar. Sem e-mail, sem senha, sem confirmar nada por código. Menos burocracia, mais organização — do jeito que deveria ser desde sempre.

#DiárioDaRiqueza #SemCadastro #Simplicidade #FinançasPessoais

---

## 05 · 05-gratuito.png

Organizar o dinheiro não devia custar dinheiro 💚

Por isso o Diário da Riqueza é 100% gratuito nos recursos principais: registro de entradas e saídas, metas, gráficos, diário e exportação dos seus dados. Sem pegadinha, sem mensalidade escondida. Comece agora.

#DiárioDaRiqueza #Grátis #AppGratuito #FinançasPessoais

---

## 06 · 06-instalar.png

Sem loja de apps, sem espera: instale em segundos ⚡

O Diário da Riqueza é um aplicativo web (PWA). Abra o site, toque em “Adicionar à tela inicial” e pronto — o ícone aparece no seu celular como qualquer outro app. Rápido, leve e sem encher seu aparelho.

#DiárioDaRiqueza #PWA #Tecnologia #Produtividade

---

## 07 · 07-receitas-despesas.png

Para onde foi o seu dinheiro esse mês? 🤔

Se a resposta é “não faço ideia”, o Diário da Riqueza foi feito para você. Registre receitas e despesas em segundos, com categorias e observações — e nunca mais fique no escuro sobre os seus gastos.

#DiárioDaRiqueza #ControleFinanceiro #ReceitasEDespesas #OrganizaçãoFinanceira

---

## 08 · 08-evolucao.png

O gráfico que você vai querer olhar todo mês 📈

Acompanhe a sua evolução financeira com gráficos claros: para onde o dinheiro vai, como seus gastos se comportam e quanto falta para a sua meta. Ver o progresso é o combustível para continuar.

#DiárioDaRiqueza #EvoluçãoFinanceira #PlanejamentoFinanceiro #Gráficos

---

## 09 · 09-metas.png

Meta sem acompanhamento é só desejo 🎯

Defina suas metas financeiras no Diário da Riqueza, acompanhe o progresso em tempo real e comemore cada conquista no caminho. Sonho com data e valor deixa de ser sonho — passa a ser plano.

#DiárioDaRiqueza #MetasFinanceiras #Objetivos #PlanejamentoFinanceiro

---

## 10 · 10-diario.png

Escrever sobre dinheiro muda a relação que você tem com ele ✍️

Além de registrar valores, o Diário da Riqueza tem espaço para observações: por que você gastou, como se sentiu, o que gostaria de fazer diferente. Com o tempo, esse hábito vira consciência — e consciência vira resultado.

#DiárioDaRiqueza #DiárioDoDinheiro #HábitosFinanceiros #ConsciênciaFinanceira

---

## 11 · 11-sequencia.png

Um dia de cada vez. É assim que o hábito se constrói 🔥

Mantenha a sua sequência de dias registrados e veja o efeito composto acontecer: registros viram rotina, rotina vira controle e controle vira tranquilidade. A consistência está do seu lado.

#DiárioDaRiqueza #Consistência #HábitosFinanceiros #Disciplina

---

## 12 · 12-backup.png

Seu histórico financeiro, protegido de verdade 🗄️

Backup automático e exportação em PDF, Excel e JSON: seus dados ficam seguros no seu aparelho e você pode levá-los para onde quiser. Trocou de celular? Seus registros vão com você.

#DiárioDaRiqueza #Backup #SegurançaDigital #OrganizaçãoFinanceira

---

## 13 · 13-orcamento.png

Um orçamento que cabe na rotina — e que você realmente mantém 🧾

Nada de planilha complicada: no Diário da Riqueza você organiza gastos fixos e variáveis, acompanha limites e vê a projeção até a sua meta. Orçamento simples é orçamento que funciona.

#DiárioDaRiqueza #Orçamento #PlanejamentoFinanceiro #GastosFixos

---

## 14 · 14-citacao.png

Riqueza se constrói na disciplina de cada dia. 💛

Não existe atalho: existe constância. Registre, acompanhe, ajuste — todos os dias. É assim que a organização financeira deixa de ser esforço e vira estilo de vida. Salve este post para lembrar. 📌

#DiárioDaRiqueza #MindsetFinanceiro #Disciplina #Motivação

---

## 15 · 15-mural-fundadores.png

75 nomes já fazem parte da história deste projeto 🏛️

O Mural dos Fundadores eterniza as pessoas que apoiaram o Diário da Riqueza desde o começo — e segue aberto para quem quiser fazer parte. Conheça o projeto, apoie e deixe o seu nome registrado.

#DiárioDaRiqueza #MuralDosFundadores #Comunidade #ApoieOProjeto

---

## 16 · 16-apoio-5.png

Um café que mantém um projeto de pé ☕

Com R$ 5 você apoia o Diário da Riqueza e ajuda a manter o app no ar: gratuito, sem anúncios e sem cadastro para todo mundo. Feito de forma independente, com muito carinho. Todo apoio conta — muito.

Apoie em: diariodariqueza.vercel.app

#DiárioDaRiqueza #ApoieOProjeto #Comunidade #Indie

---

## 17 · 17-apoio-15.png

Quer entrar para a história? Por R$ 15 você entra. 📜

Quem apoia o Diário da Riqueza com R$ 15 ganha um lugar no Mural dos Fundadores: o nome fica eternizado dentro da aplicação, para sempre. Um apoio pequeno, uma marca permanente.

Apoie em: diariodariqueza.vercel.app

#DiárioDaRiqueza #MuralDosFundadores #ApoieOProjeto #Comunidade

---

## 18 · 18-apoio-50.png

R$ 50 que aceleram o projeto 🚀

Com R$ 50 de apoio, você entra em destaque no Mural dos Fundadores e ajuda a financiar as próximas funcionalidades do Diário da Riqueza. É o combustível que transforma ideias em recursos de verdade.

Apoie em: diariodariqueza.vercel.app

#DiárioDaRiqueza #ApoieOProjeto #MuralDosFundadores #Comunidade

---

## 19 · 19-fundador-ouro.png

Fundador Ouro: o seu nome eternizado no app 👑

Por R$ 9,90/mês você se torna Fundador Ouro do Diário da Riqueza: nome eternizado no Mural dos Fundadores, título exclusivo e o apoio que garante a evolução contínua do projeto. Vagas de fundador são para sempre.

Assine em: diariodariqueza.vercel.app

#DiárioDaRiqueza #FundadorOuro #MuralDosFundadores #ApoieOProjeto

---

## 20 · 20-cta-final.png

Comece hoje. É grátis. Leva menos de 1 minuto. ⏱️

1️⃣ Acesse diariodariqueza.vercel.app
2️⃣ Toque em “Adicionar à tela inicial”
3️⃣ Registre a sua primeira entrada

Grátis, offline, sem cadastro. O melhor dia para começar a se organizar foi ontem — o segundo melhor é hoje. Compartilhe com alguém que precisa disso. 🔁

#DiárioDaRiqueza #ComeceAgora #AppGrátis #FinançasPessoais
